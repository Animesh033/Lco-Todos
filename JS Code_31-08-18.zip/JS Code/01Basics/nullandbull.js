// Temperature is comming from website API
let temp 
console.log("Current temperature is: " + temp)

// Grade System
// 10 = Great job
// 5 = Work harder
// 2 = Poor 
// 0 = Fail

// Boolean = true/false

let actualMarks = 7

let myGrade = (actualMarks < 10)

console.log(myGrade)
