var score = 100
score = 130

var bonus = 20

var finalScore = (score + bonus) * 1.8

var complex = ((4 + 4) * 4 ) / 2

// console.log(finalScore)
// console.log(complex)

let tempInFahrenheit = 100
let celsius = (tempInFahrenheit - 32) * 5/9

console.log(celsius)