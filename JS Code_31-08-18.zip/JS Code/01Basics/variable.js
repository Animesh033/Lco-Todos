let name = 'John'
let score = 120.0
let bonus = 20
let totalScore = score + bonus
console.log(totalScore)
let firstName = 'john'
firstName = 'Jane'

let lastName = 'Doe'

let fullName = firstName + '_' + lastName

console.log(firstName + ' '+ lastName)

console.log(fullName)