let myObjects = {
    title: 'Loops in javascript',
    videoLength: 15, // In minutes lets assume
    videoCreator: 'Animesh',
    VideoDescription: 'This is a video description and a long one'

}

console.log(myObjects)
console.log(`Hey new video on ${myObjects.title} By ${myObjects.videoCreator}`)