// let numOne = 22
// let numTwo = 7
// let result = 22/7
// console.log(result.toFixed(2))
// let floatRes = result.toFixed(2)

// console.log(Math.ceil(floatRes))

// console.log(Math.random() * 5 + 1)

let upper = 25
let lower = 20
let myRandom = Math.floor((Math.random() * (upper - lower + 1)) + lower)

console.log(myRandom)